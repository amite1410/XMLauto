package com.fareprice.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="product_category")
public class ProductCategoryBean {
  @Id
  @GeneratedValue
  @Column(name="product_id")
  private int productId;
  @Column(name="product_name")
  private String productName;
  @Column(name="product_status")
  private String productStatus;
  @OneToMany(fetch=FetchType.LAZY,mappedBy="productCategory")
  private Set<ProductSubcategoryBean> productSubcategoryBeans=new HashSet<>(0);
  
public int getProductId() {
	return productId;
}
public void setProductId(int productId) {
	this.productId = productId;
}
public String getProductName() {
	return productName;
}
public void setProductName(String productName) {
	this.productName = productName;
}
public String getProductStatus() {
	return productStatus;
}
public void setProductStatus(String productStatus) {
	this.productStatus = productStatus;
}
public Set<ProductSubcategoryBean> getProductSubcategoryBeans() {
	return productSubcategoryBeans;
}
public void setProductSubcategoryBeans(
		Set<ProductSubcategoryBean> productSubcategoryBeans) {
	this.productSubcategoryBeans = productSubcategoryBeans;
}
}
