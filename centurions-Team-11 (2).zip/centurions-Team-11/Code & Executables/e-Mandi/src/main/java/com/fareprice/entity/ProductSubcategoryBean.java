package com.fareprice.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="product_sub_category")
public class ProductSubcategoryBean {
	@Id
	@GeneratedValue
	@Column(name="subproduct_id")
	private int subproductId;
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="product_Id")
	ProductCategoryBean productCategory;
	@Column(name="subproduct_name")
	private String subProductName;
	@Column(name="demand_quantity")
	private double demandQuantity;
	@Column(name="supply_quantity")
	private double supplyQuantity;
	@Column(name="price")
	private double price;
	@Column(name="subproduct_status")
	private String subproductStatus;
	
	
	public int getSubproductId() {
		return subproductId;
	}
	public void setSubproductId(int subproductId) {
		this.subproductId = subproductId;
	}
	public ProductCategoryBean getProductCategory() {
		return productCategory;
	}
	public void setProductCategory(ProductCategoryBean productCategory) {
		this.productCategory = productCategory;
	}
	public String getSubProductName() {
		return subProductName;
	}
	public void setSubProductName(String subProductName) {
		this.subProductName = subProductName;
	}
	
	public void setSupplyQuantity(long supplyQuantity) {
		this.supplyQuantity = supplyQuantity;
	}

	public String getSubproductStatus() {
		return subproductStatus;
	}
	public void setSubproductStatus(String subproductStatus) {
		this.subproductStatus = subproductStatus;
	}
	public double getDemandQuantity() {
		return demandQuantity;
	}
	public void setDemandQuantity(double demandQuantity) {
		this.demandQuantity = demandQuantity;
	}
	public double getSupplyQuantity() {
		return supplyQuantity;
	}
	public void setSupplyQuantity(double supplyQuantity) {
		this.supplyQuantity = supplyQuantity;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
	

}
