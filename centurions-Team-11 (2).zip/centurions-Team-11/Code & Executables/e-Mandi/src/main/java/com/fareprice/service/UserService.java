package com.fareprice.service;

import com.fareprice.entity.User;

public interface UserService {
    void save(User user);

    User findByUsername(String username);
}
