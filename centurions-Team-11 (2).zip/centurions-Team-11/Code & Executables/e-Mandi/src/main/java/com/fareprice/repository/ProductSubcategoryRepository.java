package com.fareprice.repository;

import java.util.List;

import com.fareprice.entity.ProductSubcategoryBean;

public interface ProductSubcategoryRepository {
	List<ProductSubcategoryBean> findAllCategories();

	List<ProductSubcategoryBean> findAllCategoriesById(int id);

	void updateSubCategoryProductDetail(ProductSubcategoryBean subCategoryBean);

	ProductSubcategoryBean findSubCategories(int subCatId);

	public ProductSubcategoryBean findBean(int id);

	public List<ProductSubcategoryBean> Charts();

}
