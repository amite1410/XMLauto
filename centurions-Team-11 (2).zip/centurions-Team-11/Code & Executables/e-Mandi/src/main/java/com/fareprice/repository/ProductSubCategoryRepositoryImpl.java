package com.fareprice.repository;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.fareprice.entity.ProductSubcategoryBean;
@SuppressWarnings("unchecked")
@Repository
@Transactional(readOnly=true)
public class ProductSubCategoryRepositoryImpl implements ProductSubcategoryRepository{
	  @PersistenceContext
	  private EntityManager em;
	@Override
	public List<ProductSubcategoryBean> findAllCategories() {
		return em.createQuery("SELECT p FROM ProductSubcategoryBean p").getResultList();
	}
	
	@Override
	public List<ProductSubcategoryBean> findAllCategoriesById(int id) {
		return em.createQuery("SELECT p FROM ProductSubcategoryBean p where p.productCategory.productId="+id).getResultList();
		}
		

	
	@Override
    public void updateSubCategoryProductDetail(ProductSubcategoryBean subCategoryBean){
	                    try{
	                    	em.merge(subCategoryBean);
	                    }catch(Exception exception){
	                    	System.out.println("error in persisting subcategoryBean");
	                    }
	   }

	@Override
	public ProductSubcategoryBean findSubCategories(int subCatId) {
	
		 return (ProductSubcategoryBean) em.createQuery("SELECT p FROM ProductSubcategoryBean p where p.subproductId="+subCatId).getSingleResult();
	}
	
	 @Override
	   public ProductSubcategoryBean findBean(int id){
		   ProductSubcategoryBean bean=null;
		   try{
			  bean=em.find(ProductSubcategoryBean.class,id);
			   }catch(Exception exception){
				   System.out.println("exception finding bean "+id);
		   }
		   return bean;
	   }
	
	 @Override
		public List<ProductSubcategoryBean> Charts() {
			List<ProductSubcategoryBean> finalList=new ArrayList<ProductSubcategoryBean>();
			List<Object[]> list=em.createQuery("select sum(p.demandQuantity),sum(p.supplyQuantity),p.productCategory.productId from ProductSubcategoryBean p group by p.productCategory.productId").getResultList();

			for(Object[] obj:list){
				ProductSubcategoryBean bean=new ProductSubcategoryBean();
				bean.setDemandQuantity(Double.parseDouble(obj[0].toString()));
				bean.setSupplyQuantity(Double.parseDouble(obj[1].toString()));
				finalList.add(bean);
			}
			return finalList;
			
		}
	

}
