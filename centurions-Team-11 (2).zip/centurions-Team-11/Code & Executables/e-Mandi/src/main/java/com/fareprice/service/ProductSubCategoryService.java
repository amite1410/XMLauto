package com.fareprice.service;

import java.util.List;

import com.fareprice.entity.ProductSubcategoryBean;

public interface ProductSubCategoryService {
	List<ProductSubcategoryBean> findAllCategories();

	List<ProductSubcategoryBean> findAllCategoriesById(int id);

	ProductSubcategoryBean findSubCategories(int subCatId);

	public List<ProductSubcategoryBean> Charts();
}
