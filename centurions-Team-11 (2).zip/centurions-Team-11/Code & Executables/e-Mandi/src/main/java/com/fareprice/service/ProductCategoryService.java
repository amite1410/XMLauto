package com.fareprice.service;

import java.util.List;

import com.fareprice.entity.ProductCategoryBean;

public interface ProductCategoryService {
	List<ProductCategoryBean> findAllCategories();
	ProductCategoryBean findCategories(int catId);
}
