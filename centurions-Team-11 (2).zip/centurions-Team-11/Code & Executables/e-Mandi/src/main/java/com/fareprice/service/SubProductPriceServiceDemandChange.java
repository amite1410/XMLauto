package com.fareprice.service;

public interface SubProductPriceServiceDemandChange {
	public void subProductPriceCalculator(int subProductId,double demandQuantiy);
}