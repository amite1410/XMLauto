package com.fareprice.repository;

import java.util.List;

import com.fareprice.entity.ProductCategoryBean;

public interface ProductCategoryRepository{
	List<ProductCategoryBean> findAllCategories();
	
	ProductCategoryBean findCategories(int catId);
}
