package com.fareprice.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fareprice.entity.ProductSubcategoryBean;
import com.fareprice.repository.ProductSubcategoryRepository;

@Service
@Transactional(readOnly=false)
public class SubProductPriceServiceDemandChangeImpl implements SubProductPriceServiceDemandChange {

	@Autowired
	ProductSubcategoryRepository productSubCategoryRepository;
	
	
	public void subProductPriceCalculator(int subProductId,double demandQuantiy){
		ProductSubcategoryBean SubcategoryProduct=(ProductSubcategoryBean) productSubCategoryRepository.findBean(subProductId);
	    double  SubcategoryProductDemand=SubcategoryProduct.getDemandQuantity();
	    double SubcategoryProductSupply=SubcategoryProduct.getSupplyQuantity();
	    double demandConstant=1000;
	    double deltaDemand=demandQuantiy;
	    double currentDemand=SubcategoryProductDemand;
	    double newDemand=currentDemand+deltaDemand;
	    double currentPrice=SubcategoryProduct.getPrice();
	    System.out.println((demandConstant-newDemand));
	    System.out.println(deltaDemand);
	    System.out.println(((demandConstant-newDemand)*deltaDemand)+currentPrice);
	    double newPrice=currentPrice+(deltaDemand/currentDemand)*currentPrice*0.4666;
	    SubcategoryProduct.setDemandQuantity(newDemand);
	    SubcategoryProduct.setPrice(newPrice);
	    SubcategoryProduct.setSupplyQuantity(SubcategoryProductSupply-demandQuantiy);
	    productSubCategoryRepository.updateSubCategoryProductDetail(SubcategoryProduct);
	}
}
