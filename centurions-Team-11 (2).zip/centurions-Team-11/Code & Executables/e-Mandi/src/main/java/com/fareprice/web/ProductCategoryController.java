package com.fareprice.web;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.fareprice.entity.ProductCategoryBean;
import com.fareprice.entity.ProductSubcategoryBean;
import com.fareprice.service.ProductCategoryService;
import com.fareprice.service.ProductSubCategoryService;
import com.fareprice.service.SubProductPriceServiceDemandChange;
import com.fareprice.service.SubProductPriceServiceSupplyChange;

@Controller
public class ProductCategoryController {
	 @Autowired
	 private ProductCategoryService productCategoryService;
	 @Autowired
	 SubProductPriceServiceSupplyChange subProductPriceServiceSupplyChange; 
	 @Autowired
	 private ProductSubCategoryService productSubCategoryService;
	 
	 @Autowired
	 private SubProductPriceServiceDemandChange subProductPriceServiceDemandChange;
	 
	 @RequestMapping(value = "/buyer", method = RequestMethod.GET)
	 public String buyer(Model model){
	 List<ProductCategoryBean> allCategories = productCategoryService.findAllCategories();
	 List<ProductSubcategoryBean> allCategories1 = productSubCategoryService.findAllCategories();
	 model.addAttribute("allCategories",allCategories);
	 model.addAttribute("allCategories1",allCategories1);
	 return "buyer";
	 }
	 @RequestMapping(value = "/seller", method = RequestMethod.GET)
	 public String seller(Model model){
	 List<ProductCategoryBean> allCategories = productCategoryService.findAllCategories();
	 List<ProductSubcategoryBean> allCategories1 = productSubCategoryService.findAllCategories();
	 model.addAttribute("allCategories",allCategories);
	 model.addAttribute("allCategories1",allCategories1);
	 return "seller";
	 }
	 
	 @RequestMapping(value = "/buyerChangeCategory", method = RequestMethod.GET)
	 public String buyerChangeCategory(Model model, HttpServletRequest request){
		 int id = Integer.parseInt(request.getParameter("categoryId"));
	 List<ProductCategoryBean> allCategories = productCategoryService.findAllCategories();
	 List<ProductSubcategoryBean> allCategories1 = productSubCategoryService.findAllCategoriesById(id);
	 model.addAttribute("allCategories",allCategories);
	 model.addAttribute("allCategories1",allCategories1);
	 model.addAttribute("catId",id);
	 return "buyer";
	 }
	 @RequestMapping(value = "/sellerChangeCategory", method = RequestMethod.GET)
	 public String sellerChangeCategory(Model model, HttpServletRequest request){
		 int id = Integer.parseInt(request.getParameter("categoryId"));
	 List<ProductCategoryBean> allCategories = productCategoryService.findAllCategories();
	 List<ProductSubcategoryBean> allCategories1 = productSubCategoryService.findAllCategoriesById(id);
	 model.addAttribute("allCategories",allCategories);
	 model.addAttribute("allCategories1",allCategories1);
	 model.addAttribute("catId",id);
	 return "seller";
	 }
	 
	 @RequestMapping(value = "/buyProduct", method = RequestMethod.GET)
	 public String buyProduct(Model model, HttpServletRequest request){
	  
	   int subCatId=Integer.parseInt(request.getParameter("subCategoryId"));
	   ProductSubcategoryBean subCategory = productSubCategoryService.findSubCategories(subCatId);
	 
	   model.addAttribute("subCategory",subCategory);
	   return "buyproduct";
	 }
	 
	 @RequestMapping(value = "/buyProduct", method = RequestMethod.POST)
	 public String updateProduct(Model model, HttpServletRequest request, RedirectAttributes redirectAttributes){
	   int subCatId=Integer.parseInt(request.getParameter("subcat"));
	   double quantity=Double.parseDouble(request.getParameter("buyquantity"));
	   System.out.println(">>>>"+subCatId);
	   System.out.println(">>>>"+quantity);
	   ProductSubcategoryBean subCategory = productSubCategoryService.findSubCategories(subCatId);
	   subProductPriceServiceDemandChange.subProductPriceCalculator(subCatId, quantity);
	   redirectAttributes.addFlashAttribute("message", "Successfully Updated");
	   model.addAttribute("subCategory",subCategory);
	   return "redirect:buyer";
	 }
	 
	 @RequestMapping(value = "/sellProduct", method = RequestMethod.GET)
	 public String cellProduct(Model model, HttpServletRequest request, RedirectAttributes redirectAttributes){
	   int subCatId=Integer.parseInt(request.getParameter("subCategoryId"));
	   double quantity=Double.parseDouble(request.getParameter("price"));
	   System.out.println(">>>>"+subCatId);
	   System.out.println(">>>>"+quantity);
	  ProductSubcategoryBean subCategory = productSubCategoryService.findSubCategories(subCatId);
	  subProductPriceServiceSupplyChange.subProductPriceCalculator(subCatId, quantity);
	   redirectAttributes.addFlashAttribute("message", "Successfully Updated");
	   model.addAttribute("subCategory",subCategory);
	   return "redirect:seller";
	 }
}
