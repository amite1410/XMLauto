package com.fareprice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fareprice.entity.ProductSubcategoryBean;
import com.fareprice.repository.ProductSubcategoryRepository;

@Service
public class ProductSubCategoryServiceImpl implements ProductSubCategoryService {
	@Autowired
	private ProductSubcategoryRepository productSubCategoryRepository;

	@Override
	public List<ProductSubcategoryBean> findAllCategories() {
		return productSubCategoryRepository.findAllCategories();
	}

	@Override
	public List<ProductSubcategoryBean> findAllCategoriesById(int id) {
		return productSubCategoryRepository.findAllCategoriesById(id);
	}

	@Override
	public ProductSubcategoryBean findSubCategories(int subCatId) {
		return productSubCategoryRepository.findSubCategories(subCatId);
	}

	@Override
	public List<ProductSubcategoryBean> Charts() {

		return productSubCategoryRepository.Charts();
	}
}
