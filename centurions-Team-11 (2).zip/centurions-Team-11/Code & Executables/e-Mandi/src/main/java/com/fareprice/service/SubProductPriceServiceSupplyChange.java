package com.fareprice.service;

public interface SubProductPriceServiceSupplyChange {
	public void subProductPriceCalculator(int subProductId,double supplyQuantiy);
}
