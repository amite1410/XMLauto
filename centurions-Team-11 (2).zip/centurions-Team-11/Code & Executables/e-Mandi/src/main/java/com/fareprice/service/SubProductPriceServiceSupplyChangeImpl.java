package com.fareprice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fareprice.entity.ProductSubcategoryBean;
import com.fareprice.repository.ProductSubcategoryRepository;

@Service
@Transactional(readOnly=false)
public class SubProductPriceServiceSupplyChangeImpl implements SubProductPriceServiceSupplyChange {
	@Autowired
	ProductSubcategoryRepository productSubCategoryRepository;
	public void subProductPriceCalculator(int subProductId, double supplyQuantiy) {
		ProductSubcategoryBean subCategoryProduct=productSubCategoryRepository.findBean(subProductId);
		double  SubcategoryProductDemand=subCategoryProduct.getDemandQuantity();
		double SubcategoryProductSupply=subCategoryProduct.getSupplyQuantity();
		double deltaSupply=supplyQuantiy;
		double currentSupply=SubcategoryProductSupply;
		double newSupply=SubcategoryProductSupply+supplyQuantiy;
		double currentPrice=subCategoryProduct.getPrice();
		double newPrice=currentPrice+(deltaSupply/currentSupply)*currentPrice*(-0.35);
		 subCategoryProduct.setSupplyQuantity(newSupply);
		 subCategoryProduct.setPrice(newPrice);
		 productSubCategoryRepository.updateSubCategoryProductDetail(subCategoryProduct);
	}

}
