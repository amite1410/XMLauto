package com.fareprice.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.fareprice.entity.ProductCategoryBean;

@Repository
@Transactional(readOnly=true)
public class ProductCategoryRepositoryImpl implements ProductCategoryRepository{
	

	  @PersistenceContext
	  private EntityManager em;

	@Override
	public List<ProductCategoryBean> findAllCategories() {
		return em.createQuery("SELECT p FROM ProductCategoryBean p").getResultList();
	}

	@Override
	public ProductCategoryBean findCategories(int catId) {
		
		 return (ProductCategoryBean) em.createQuery("SELECT p FROM ProductCategoryBean p where p.productId="+catId).getSingleResult();
	}

	
}
