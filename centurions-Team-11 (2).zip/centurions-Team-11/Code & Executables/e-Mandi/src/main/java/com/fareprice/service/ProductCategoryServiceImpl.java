package com.fareprice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fareprice.entity.ProductCategoryBean;
import com.fareprice.repository.ProductCategoryRepository;

@Service
public class ProductCategoryServiceImpl implements ProductCategoryService{

	@Autowired
	private ProductCategoryRepository productCategoryRepository;
	
	@Override
	public List<ProductCategoryBean> findAllCategories() {
		return productCategoryRepository.findAllCategories();
	}

	@Override
	public ProductCategoryBean findCategories(int catId) {
		
		return productCategoryRepository.findCategories(catId);
	}



}
