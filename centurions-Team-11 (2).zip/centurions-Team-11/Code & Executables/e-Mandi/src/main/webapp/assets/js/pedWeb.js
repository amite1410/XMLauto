/**
 * All Application Scripts
 */

/*To View EnodeB ID Details*/
function setEnodebDetails(enodebId, enodebName, marketName, marketCluster, region, vendor, projectType, submitter, providedDate, requestedDate) {
	$('#userMsg').hide();
	document.getElementById("enodeb_Id").innerHTML = enodebId;
	document.getElementById("enodeb_Name").innerHTML = enodebName;
	document.getElementById("market_Name").innerHTML = marketName;
	document.getElementById("market_Cluster").innerHTML = marketCluster;
	document.getElementById("region_val").innerHTML = region;
	document.getElementById("vendor_val").innerHTML = vendor;
	document.getElementById("project_Type").innerHTML = projectType;
	document.getElementById("submitter_val").innerHTML = submitter;
	document.getElementById("provided_Date").innerHTML = providedDate;
	document.getElementById("requested_Date").innerHTML = requestedDate;
}

/*To View EnodeB Name Details*/
function setEnodebNameData(enodebName, enodebTechType,bsrName,mscClli,county,marketName, marketCluster,region,vendor,status,timeZone) {
	$('#userMsg').hide();
	document.getElementById("enodeb_Name").innerHTML = enodebName;
	document.getElementById("tech_Type").innerHTML = enodebTechType;
	if(bsrName == ""){
		document.getElementById("bsr_Name").innerHTML = "N/A";
	}
	else{
		document.getElementById("bsr_Name").innerHTML = bsrName;		
	}
	document.getElementById("mscclli_val").innerHTML = mscClli;
	document.getElementById("county_val").innerHTML = county;
	document.getElementById("market_Name").innerHTML = marketName;
	document.getElementById("market_Cluster").innerHTML = marketCluster;
	document.getElementById("region_val").innerHTML = region;
	document.getElementById("vendor_val").innerHTML = vendor;
	document.getElementById("status_val").innerHTML = status;
	document.getElementById("time_Zone").innerHTML = timeZone;
}

/*To Delete EnodeB ID row*/
function confirmEnodebIdDelete(enodebId) {
	$('#userMsg').hide();
	bootbox.confirm("Are you sure you want to delete Enodeb Id : " + enodebId + " ?", function(result) {
		if (result) {
			$("#loading").show();
			window.location="/ped-web/deleteEnodebID?enodebID="+enodebId;
		}
	});
}

/*To check start date and end date*/
function createEnodebName(){
	$('#userMsg').hide();
	var startDate = new Date(document.getElementById("startDatePicker").value);
	var endDate = new Date(document.getElementById("endDatePicker").value); 
	if(startDate.getTime() > endDate.getTime()){
		$("#dateAlert").slideDown().delay(1500).slideUp();
	}
	return false;
}

/*To Update Telegance record*/
function confirmTelegenceReload(id, ctn) {
	$('#userMsg').hide();
	bootbox.confirm("Reload for Telegance ID : " + id + " & CTN : "+ ctn +" ?", function(result) {
		if (result) {
			$("#loading").show();
			window.location="/ped-web/updateTelegence?id="+id+"&ctn="+ctn; 
		}
	});
    }

/*To Delete Telegance record*/
function confirmTelegenceDelete(id, ctn) {
	$('#userMsg').hide();
	bootbox.confirm("Delete for Subscriber ID : " + id + " & CTN : "+ ctn +" ?", function(result) {
		if (result) {
			$("#loading").show();
			window.location="/ped-web/deleteTelegence?id="+id+"&ctn="+ctn;
		}
	});
    }


/*To Bulk Update Telegance record*/
function confirmTelegenceBulkLoad() {
	$('#userMsg').hide();
	 bootbox.confirm("Are You Sure for Telegence Bulk Reload ?", function(result) {
	    	if (result) {
	    		$("#loading").show();
	    		window.location = "/ped-web/bulkUpdateTelegence";
	    	}
	    });
    }

function setRoleDetails(roleId, roleName, roleDetails) {
	$('#userMsg').hide();
	document.getElementById("role_id").value = roleId.toString();
	document.getElementById("role_name").value = roleName;
	document.getElementById("role_description").value = roleDetails;
    }

function confirmRoleDelete(roleId, roleName) {
	$('#userMsg').hide();
    bootbox.confirm("Are you sure you want to delete "+ roleName + " Role ?", function(result) {
    	if (result) {
    		$("#loading").show();
    		window.location = "/ped-web/deleteRole?roleID=" + roleId;
    	}
    });
}

/* To Display Available Roles & Assigned Roles on Manage Roles Multi-select box */
function manageUserRole(colid){
	$('#userMsg').hide();
	document.getElementById("userID").innerHTML = colid;
	$('#availableRole').empty();
	$('#assignedRole').empty();
	var allArrList = [];
	var userArrList = [];
	var allArr = $('#allUser').text().split('/');
	var userArr = $('.cuurentRole_' + colid).text().split(',');
	for(i=0; i<allArr.length-1;i++) {
		if(userArr.indexOf(allArr[i])<0){
			allArrList.push('<li class="list-group-item">'+ allArr[i]+'</li>');
		}
	}
	$('#availableRole').append(allArrList.join(''));
	
	for(i=0; i<userArr.length;i++) {
		userArrList.push('<li class="list-group-item">'+ userArr[i]+'</li>');
	}
	$('#assignedRole').append(userArrList.join(''));
}

/*To refresh properties on refresh button click*/
function refreshProperty() {
	$.ajax({
		type : "get",
		dataType : 'jsonp',
		crossDomain : true,
		url : "http://t1c1m462.vci.att.com:8003/ped/loadDBProp",
		cache : false,
		success : function(response) {
			alert(response);
		},
		error : function(request, xhr, ajaxOptions, thrownError) {
			if (JSON.stringify(request).indexOf("200") > -1) {
				alert("Successfully Loaded DB Properties !");
			}
		}
	});
}

function setPropDetails(propKey,propValue) {
	$('#userMsg').hide();
	document.getElementById("prop_key").value = propKey.toString();
	document.getElementById("prop_value").value = propValue.toString();
	document.getElementById("hiddenPropKey").value = propKey.toString();
	document.getElementById("prop_key").disabled = true; 
    }
function confirmPropertyDelete(propKey, propValue) {
	$('#userMsg').hide();
	bootbox.confirm("Are you sure you want to delete Property : " + propKey + " - "+ propValue+" ?",function(result) {
				if (result) {
					$("#loading").show();
					window.location = "deleteProperty?propKey=" + propKey;
				}
			});
}

function deletePedWebProperty(propKey, propValue) {
	$('#userMsg').hide();
	bootbox.confirm("Are you sure you want to delete Property : " + propKey + " - "+ propValue+" ?",function(result) {
				if (result) {
					$("#loading").show();
					window.location = "deletePedProperty?propKey=" + propKey;
				}
			});
}
function clearHiddenKey() {
	document.getElementById("hiddenPropKey").value = "";
}


$(document).ready(
		function() {
			
			$('#example').DataTable( {
		        "order": [[ 0, "desc" ]]
		    } );
			
			/* For loading image */
			$(".load").click(function(){
				$("#loading").show();	
			});
			$(window).load(function() {
			     $('#loading').hide();
			  });
			
			//Date picker
			 $( ".datepicker" ).datepicker({
				  dateFormat: "yy-mm-dd"
				});
			 
			/*To Display User Role under Welcome Section*/
			if (($('#userRole').text().split('/')).indexOf("ADMIN") > -1) {
				$('#logRole').html("Logged in as ADMIN");
			} else if (($('#userRole').text().split('/')).indexOf("ENODEB") > -1) {
				$('#logRole').html("Logged in as ENODEB");
			} else {
				if (($('#userRole').text().split('/')).indexOf("TELEGANCE") > -1) {
					$('#logRole').html("Logged in as TELEGANCE");
				} else {
					$('#logRole').html("GUEST User");
				}
				$("#widget1, #widget2, #enodebIdTab, #enodebNameTab").hide();
				$("#widget3, #widget4").removeClass('col-md-3').addClass('col-md-6');
			}
			
			/*To generate data table*/
			$('#example').DataTable();
			
			//To enable only Dashboard for Guest User
			$('.adminTelegance').click(function() {
				if (($('#userRole').text().split('/')).indexOf("ADMIN")>-1 || ($('#userRole').text().split('/')).indexOf("TELEGANCE")>-1) {
					$('.adminTelegance').attr("data-toggle", "dropdown");
				} else {
					$("#roleModal").slideDown().delay(1000).slideUp();
				}
			})
			
			 $('.adminEnodeB').click(function() {
				if (($('#userRole').text().split('/')).indexOf("ADMIN")>-1 || ($('#userRole').text().split('/')).indexOf("ENODEB")>-1) {
					$('.adminEnodeB').attr("data-toggle", "dropdown");
				} else {
					$("#roleModal").slideDown().delay(1000).slideUp();
				}
			})
			
			//To allow only Admin to access Admin Section 
			$('.adminOnly').click(function() {									
				if (($('#userRole').text().split('/')).indexOf("ADMIN")>-1) {
					$('.adminOnly').attr("data-toggle", "dropdown");
				} else {
					$("#roleModal").slideDown().delay(1000).slideUp();
				}
			})
			
			/*To submit assigned roles to user from Manage Roles*/
			$("#submitRole").click(
					function() {
						if($('.list-right ul li').length < 1){
	                    		$("#assignedAlert").slideDown().delay(1500).slideUp();
	                    	return false;
	                    }
						var allRoles = "";
						var attuid = $("#userID").text();
						$("#assignedRole li").each(function() {
							if (allRoles == "") {
								allRoles += $(this).text();
							} else {
								allRoles += "/" + $(this).text();
							}
						});
						window.location = "addUserRoles?roles=" + allRoles
								+ "&&attid=" + attuid; // return allRoles;
					});
		});
